﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeatherWebClient.POCO
{
    class WeatherBitAPIForecast
    {
        private string dateTime;
        private float minimum;
        private float maximum;

        public WeatherBitAPIForecast(string dateTime, float minimum, float maximum)
        {
            this.dateTime = dateTime;
            this.minimum = minimum;
            this.maximum = maximum;
        }

        public string getDateTime()
        {
            return dateTime;
        }

        public float getMinimum()
        {
            return minimum;
        }

        public float getMaximum()
        {
            return maximum;
        }
    }
}
