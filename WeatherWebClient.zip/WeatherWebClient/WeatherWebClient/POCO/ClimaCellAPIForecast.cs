﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeatherWebClient.POCO
{
    class ClimaCellAPIForecast
    {
       
        private float MinValue;
        private float MaxValue;

        public ClimaCellAPIForecast(float MinValue, float MaxValue)
        {
            this.MinValue = MinValue; 
            this.MaxValue = MaxValue; 
        }
        public float getMinValue()
        {
            return MinValue; 
        }           
        public float getMaxValue()
        {
            return MaxValue; 
        }   
        
    }
}
