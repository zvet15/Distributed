﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeatherWebClient.POCO
{
    class DarkSkyForecast
    {
        private DateTime time;
        private float temperatureMin;
        private float temperatureMax;

        public DarkSkyForecast(long epochDateTime, float temperatureMin, float temperatureMax)
        {
            DateTimeOffset dateTimeOffset = DateTimeOffset.FromUnixTimeSeconds(epochDateTime);
            time = dateTimeOffset.UtcDateTime;
            this.temperatureMin = temperatureMin;
            this.temperatureMax = temperatureMax;
        }

        public DateTime getDateTime()
        {
            return time;
        }

        public float getMinimum()
        {
            return temperatureMin;
        }

        public float getMaximum()
        {
            return temperatureMax;
        }
    }
}
