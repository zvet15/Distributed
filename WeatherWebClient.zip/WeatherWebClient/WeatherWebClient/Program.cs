﻿using System;
using WeatherWebClient.Controller;
using WeatherWebClient.POCO;

namespace WeatherWebClient
{
    class Program
    {
        static void Main(string[] args)
        {
            //OpenWeatherMapAPI();
            //AccuWeatherAPI();
            //WeatherBitAPI();
            //DarkSkyAPI();
            //Weather2020();
            ClimaCell();
            Console.ReadKey();
        }

        //private static void OpenWeatherMapAPI()
        //{
        //    string cityName = "Valletta";

        //    /**** Open Weather Map ****/
        //    /**** Current Weather ****/
        //    OpenWeatherMapController openWeatherMapController = new OpenWeatherMapController();

        //    Console.WriteLine("***** Open Weather Map *****");
        //    Console.WriteLine("***** Current Weather API *****");
        //    Console.WriteLine($"Current Temperature for {cityName}: {openWeatherMapController.getCurrentWeather(cityName)}");

        //    /**** FORECAST****/
        //    Console.WriteLine("***** Forecast API *****");
        //    Console.WriteLine($"Forecast for {cityName}: ");
        //    foreach (OpenWeatherMapForecast forecast in openWeatherMapController.getForecast(cityName))
        //    {
        //        Console.WriteLine($"{forecast.getDateTime().ToString()} Temperature: {forecast.getTemperature()}");
        //    }
        //}

        //private static void AccuWeatherAPI()
        //{
        //    string cityName = "Valletta";

        //    /**** AccuWeather ****/
        //    /**** Current Weather ****/
        //    AccuWeatherController accuWeatherController = new AccuWeatherController();

        //    Console.WriteLine("***** AccuWeather *****");
        //    Console.WriteLine("***** Current Weather API *****");
        //    Console.WriteLine($"Current Temperature for {cityName}: {accuWeatherController.getCurrentWeather(cityName)}");

        //    /**** FORECAST****/
        //    Console.WriteLine("***** Forecast API *****");
        //    Console.WriteLine($"Forecast for {cityName}: ");
        //    foreach (AccuWeatherForecast forecast in accuWeatherController.getForecast(cityName))
        //    {
        //        Console.WriteLine($"{forecast.getDateTime().ToString()} Minimum: {forecast.getMinimum()} Maximum: {forecast.getMaximum()}");
        //    }

        //}

        //private static void WeatherBitAPI()
        //{
        //    string cityName = "Valletta";
        //    string country = "MT";

        //    /**** Weather Bit ****/
        //    /**** Current Weather ****/
        //    WeatherBitController weatherBitController = new WeatherBitController();

        //    Console.WriteLine("***** Open Weather Map *****");
        //    Console.WriteLine("***** Current Weather API *****");
        //    Console.WriteLine($"Current Temperature for {cityName}: {weatherBitController.getCurrentWeather(cityName,country)}");

        //    /**** FORECAST****/
        //    Console.WriteLine("***** Forecast API *****");
        //    Console.WriteLine($"Forecast for {cityName}: ");
        //    foreach (WeatherBitAPIForecast forecast in weatherBitController.getForecast(cityName))
        //    {
        //        Console.WriteLine($"{forecast.getDateTime()} Temperature: Minimum: {forecast.getMinimum()} Maximum: {forecast.getMaximum()}");
        //    }
        //}

        //private static void DarkSkyAPI()
        //{ 
        //    string cityName = "Fgura"; 

        //    /**** Weather Bit ****/
        //    /**** Current Weather ****/
        //    DarkSkyController darkSkyController = new DarkSkyController();

        //    Console.WriteLine("***** Open Weather Map *****");
        //    Console.WriteLine("***** Current Weather API *****");
        //    Console.WriteLine($"Current Temperature : {darkSkyController.getCurrentWeather(cityName)}");

        //    /**** FORECAST****/
        //    Console.WriteLine("***** Forecast API *****");
        //    Console.WriteLine($"Forecast for {cityName}: ");
        //    foreach (DarkSkyForecast forecast in darkSkyController.getCurrentWeatherForecast(cityName))
        //    {
        //        Console.WriteLine($"{forecast.getDateTime()} Temperature: Minimum: {forecast.getMinimum()} Maximum: {forecast.getMaximum()}");
        //    }
        //}
        //private static void Weather2020()
        //{
        //    double latitude = 39.09972;
        //    double longitude = -94.57856;

        //    /**** Weather Bit ****/
        //    /**** Current Weather ****/
        //    Weather2020Controller weather2020Controller = new Weather2020Controller();

        //    Console.WriteLine("***** Open Weather Map *****");
        //    Console.WriteLine("***** Current Weather API *****");
        //    Console.WriteLine($"Current Temperature : {weather2020Controller.getCurrentWeather(latitude,longitude)}");
        //}


        private static void ClimaCell()
        {
            double latitude = 39.09972;
            double longitude = -94.57856;
            string start_now = "now";
            string end_now= "2020-03-25T14:09:50Z";

            /**** Weather Bit ****/
            /**** Current Weather ****/
            ClimaCellController climaCellController = new ClimaCellController();

            Console.WriteLine("***** Open Weather Map *****");
            Console.WriteLine("***** Current Weather API *****");
            Console.WriteLine($"Current Temperature : {climaCellController.getCurrentWeather(latitude, longitude)}");

            // ****FORECAST * ***//
            Console.WriteLine("***** Forecast API *****"); 
            foreach (ClimaCellAPIForecast forecast in climaCellController.getForecast(latitude,longitude,start_now,end_now))
            {
                Console.WriteLine($"{forecast.getMinValue()}{forecast.getMaxValue()}");
            }
        }
    }

}
