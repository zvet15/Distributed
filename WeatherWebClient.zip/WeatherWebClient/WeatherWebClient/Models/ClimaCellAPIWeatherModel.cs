﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace WeatherWebClient.Models
{

    [DataContract]
    class ClimaCellAPIWeatherModel
    {
        [DataMember]
        public Temp temp;
    }

    [DataContract]
    class Temp
    {
        [DataMember]
        public double value { get; set; }
    }
}
