﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace WeatherWebClient.Models
{
    [DataContract]
    class ClimaCellAPIForecastModel
    {
        [DataMember]
        public List<ForecastTemp> temp { get; set; }     
    }

 
    [DataContract]
    class ForecastTemp
    {
        [DataMember]
        public TempMin min { get; set; }

        [DataMember]
        public TempMax max { get; set; }
    }

    [DataContract]
    class TempMin
    {
        [DataMember]
        public float value { get; set; }
    }   
    
    [DataContract]
    class TempMax
    {
        [DataMember]
        public float value { get; set; }
    }
}
