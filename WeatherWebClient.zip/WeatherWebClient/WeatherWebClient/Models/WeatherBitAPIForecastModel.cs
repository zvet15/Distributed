﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace WeatherWebClient.Models.Forecast
{
    [DataContract]
    class WeatherBitAPIForecastModel
    {
        [DataMember]
        public List<Data> data;
    }
    [DataContract]
    class Data
    {
        [DataMember]
        public string datetime { get; set; }

        [DataMember]
        public float min_temp { get; set; }

        [DataMember]
        public  float max_temp{ get; set; }

    }

}
