﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace WeatherWebClient.Models
{


    [DataContract]
    class DarkSkyWeatherModel
    {
        [DataMember]
        public Currently currently;

    }
    [DataContract]
    class Currently
    {
        [DataMember]
        public float temperature { get; set; }
    }

 

}
