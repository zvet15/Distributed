﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace WeatherWebClient.Models
{

    [DataContract]
    class Weather2020Model
    {
        [DataMember]
        public int temperatureHigh { get; set; }

        [DataMember]
        public int temperatureLow { get; set; }


    }
}
 
