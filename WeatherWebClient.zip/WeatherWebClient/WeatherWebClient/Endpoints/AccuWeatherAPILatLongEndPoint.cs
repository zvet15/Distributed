﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeatherWebClient.Endpoints
{
    class AccuWeatherAPILatLongEndPoint: Endpoint
    {
        public AccuWeatherAPILatLongEndPoint() :
      base("http://dataservice.accuweather.com/locations/v1/cities/search",
      "B02sOGAdf3H3KLTWyPNDGaPAbtCEHVGJ")
        { }

        public string getLatAndLongEndpoint(string cityName)
        {
            StringBuilder stringBuilder = new StringBuilder(baseEndpoint);
          //  stringBuilder.Append(getEndpointType());
            stringBuilder.Append("?apikey=");
            stringBuilder.Append(apiKey);
            stringBuilder.Append("&q=");
            stringBuilder.Append(cityName); 
            return stringBuilder.ToString();
        }
    }
}
