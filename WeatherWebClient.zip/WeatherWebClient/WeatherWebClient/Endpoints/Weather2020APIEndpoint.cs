﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeatherWebClient.Endpoints
{
    class Weather2020APIEndpoint:Endpoint
    {
        public Weather2020APIEndpoint() :
     base("http://api.weather2020.com/",
     "e8ecee8ff60c478f8a36280fea0524fe")
        { }

        public string getWeather(double lat, double lon)
        {
            StringBuilder stringBuilder = new StringBuilder(baseEndpoint); 
            stringBuilder.Append(apiKey);
            stringBuilder.Append("/"); 
            stringBuilder.Append(lat);
            stringBuilder.Append(",");
            stringBuilder.Append(lon);
            return stringBuilder.ToString();
        }

    }
}
