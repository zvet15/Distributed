﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeatherWebClient.Endpoints
{
    class DarkSkyAPIEndpoint: Endpoint
    {
        public DarkSkyAPIEndpoint() :
        base("https://api.darksky.net/",
        "ce12c3721a6c2ca291440c698ce98c8e")
        { }
        public string getCurrentWeatherEndpoint(string coordinates)
        {
            StringBuilder stringBuilder = new StringBuilder(baseEndpoint);
            stringBuilder.Append(getEndpointType());
            stringBuilder.Append("/");
            stringBuilder.Append(apiKey);
            stringBuilder.Append("/");
            stringBuilder.Append(coordinates);
            stringBuilder.Append("?units=si");
            return stringBuilder.ToString();

        }

    }
}
