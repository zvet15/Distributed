﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeatherWebClient.Endpoints
{
    class WeatherBitAPIEndpoint: Endpoint
    {
        public WeatherBitAPIEndpoint() :
    base("http://api.weatherbit.io/v2.0/",
        "aa264e2681624799b651135c27d9dc92")
        { }


        //api.openweathermap.org/data/2.5/{EndpointType}?q={city name}&appid={your api key}&units=metric
        public string getByCityNameEndpoint(string cityName, string country)
        {
            StringBuilder stringBuilder = new StringBuilder(baseEndpoint);
            stringBuilder.Append(getEndpointType());
            stringBuilder.Append("?Key=");
            stringBuilder.Append(apiKey); 
            stringBuilder.Append("&units=M");        
            stringBuilder.Append("&city=");
            stringBuilder.Append(cityName);
            stringBuilder.Append("&country=");
            stringBuilder.Append(country);
            return stringBuilder.ToString();
        }


        public string getByCityNameForecastEndpoint(string cityName)
        {
            StringBuilder stringBuilder = new StringBuilder(baseEndpoint);
            stringBuilder.Append(getEndpointType());
            stringBuilder.Append("/daily?city=");
            stringBuilder.Append(cityName);
            stringBuilder.Append(",MT&Key=");
            stringBuilder.Append(apiKey); 
            return stringBuilder.ToString();
        }
    }
}
