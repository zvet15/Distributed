﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeatherWebClient.Endpoints
{
    class ClimaCellAPIEndpoint : Endpoint
    {
        public ClimaCellAPIEndpoint() :
     base("https://api.climacell.co/v3/",
     "Zw25KQ80BiV2kY6ABsMxIZLiI3wLyZp9")
        { }

        public string getTemperature(double lat, double lon)
        {
            StringBuilder stringBuilder = new StringBuilder(baseEndpoint);
            stringBuilder.Append(getEndpointType());
            stringBuilder.Append("/realtime");
            stringBuilder.Append("?apikey=");
            stringBuilder.Append(apiKey);
            stringBuilder.Append("&lat="); 
            stringBuilder.Append(lat);
            stringBuilder.Append("&lon=");
            stringBuilder.Append(lon);
            stringBuilder.Append("&fields=temp:C");
            return stringBuilder.ToString();
        }

        public string getTemperatureForecast(double lat, double lon,string now,string time)
        {
            StringBuilder stringBuilder = new StringBuilder(baseEndpoint);
            stringBuilder.Append("weather/forecast"); 
            stringBuilder.Append("/");
            stringBuilder.Append("daily");
            stringBuilder.Append("?apikey=");
            stringBuilder.Append(apiKey);
            stringBuilder.Append("&lat=");
            stringBuilder.Append(lat);
            stringBuilder.Append("&lon=");
            stringBuilder.Append(lon);
            stringBuilder.Append("&start_time=");
            stringBuilder.Append(now);
            stringBuilder.Append("&end_time=");
            stringBuilder.Append(time);
            stringBuilder.Append("&fields=temp:C");
            return stringBuilder.ToString();
        }

    }
}
