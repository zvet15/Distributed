﻿using System;
using System.Collections.Generic;
using System.Text;
using WeatherWebClient.Endpoints;
using WeatherWebClient.JSONParser;
using WeatherWebClient.Models;
using WeatherWebClient.Models.Weather;
using WeatherWebClient.POCO;
using Data = WeatherWebClient.Models.Data;

namespace WeatherWebClient.Controller
{
    class DarkSkyController : Controller
    {

        private DarkSkyAPIEndpoint darkSkyAPIEndpoint;
        private AccuWeatherAPILatLongEndPoint accuWeatherAPILatLongEndPoint;
        public DarkSkyController() : base()
        {
            this.darkSkyAPIEndpoint = new DarkSkyAPIEndpoint();
            this.accuWeatherAPILatLongEndPoint = new AccuWeatherAPILatLongEndPoint();
        }

        private string getCoordinates(string cityName)
        {
            float lat = 0f;
            float longitude = 0f;

            string response = getResponse(accuWeatherAPILatLongEndPoint.getLatAndLongEndpoint(cityName));
            System.Diagnostics.Debug.WriteLine(response);

            using (JsonParser<List<AccuWeatherAPILatLongModel>> jsonParser = new JsonParser<List<AccuWeatherAPILatLongModel>>())
            {
                List<AccuWeatherAPILatLongModel> accuWeatherAPILatLongModel = new List<AccuWeatherAPILatLongModel>();
                accuWeatherAPILatLongModel = jsonParser.parse(response, netCoreVersion);

                //temperature = darkSkyForecastModel.data[0].temp;
                lat = accuWeatherAPILatLongModel[0].GeoPosition.Latitude;
                longitude = accuWeatherAPILatLongModel[0].GeoPosition.Longitude;
            }
            return lat + "," + longitude;
        }

        public float getCurrentWeather(string cityName)
        {
            /**** Current Weather ****/

            float temperature = 0f;
            string coordinates = getCoordinates(cityName);

            darkSkyAPIEndpoint.endpointType = EndpointType.FORECAST;
            string response = getResponse(darkSkyAPIEndpoint.getCurrentWeatherEndpoint(coordinates));
            System.Diagnostics.Debug.WriteLine(response);

            using (JsonParser<DarkSkyWeatherModel> jsonParser = new JsonParser<DarkSkyWeatherModel>())
            {
                DarkSkyWeatherModel darkSkyForecastModel = new DarkSkyWeatherModel();
                darkSkyForecastModel = jsonParser.parse(response, netCoreVersion);

                //temperature = darkSkyForecastModel.data[0].temp;
                temperature = darkSkyForecastModel.currently.temperature;
            }

            return temperature;
        }

        public List<DarkSkyForecast> getCurrentWeatherForecast(string cityName)
        {
            List<DarkSkyForecast> forecastList = new List<DarkSkyForecast>();

            string coordinates = getCoordinates(cityName);

            darkSkyAPIEndpoint.endpointType = EndpointType.FORECAST;
            string response = getResponse(darkSkyAPIEndpoint.getCurrentWeatherEndpoint(coordinates));
            System.Diagnostics.Debug.WriteLine(response);

            using (JsonParser<DarkSkyForecastModel> jsonParser = new JsonParser<DarkSkyForecastModel>())
            {
                DarkSkyForecastModel darkSkyForecastModel = new DarkSkyForecastModel();
                darkSkyForecastModel = jsonParser.parse(response, netCoreVersion);

                foreach (Data data in darkSkyForecastModel.daily.data)
                {
                    forecastList.Add(new DarkSkyForecast(data.time, data.temperatureMin, data.temperatureMax));
                }
            }
            return forecastList;
        }
    }
}
