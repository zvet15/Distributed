﻿using System;
using System.Collections.Generic;
using System.Text;
using WeatherWebClient.Endpoints;
using WeatherWebClient.JSONParser; 
using WeatherWebClient.Models;
using WeatherWebClient.POCO; 
namespace WeatherWebClient.Controller
{
    class ClimaCellController:Controller
    {
        private ClimaCellAPIEndpoint climaCellAPIEndpoint;


        public ClimaCellController() : base()
        {
            climaCellAPIEndpoint = new ClimaCellAPIEndpoint();
        }

        public double getCurrentWeather(double latitude, double longitude)
        {
            /**** Current Weather ****/

            double temp; 

            string response = getResponse(climaCellAPIEndpoint.getTemperature(latitude, longitude));

            System.Diagnostics.Debug.WriteLine(response);

            using (JsonParser<ClimaCellAPIWeatherModel> jsonParser = new JsonParser<ClimaCellAPIWeatherModel>())
            {

                ClimaCellAPIWeatherModel climaCellAPIWeatherModel = new ClimaCellAPIWeatherModel();
                climaCellAPIWeatherModel = jsonParser.parse(response, netCoreVersion);

                temp = climaCellAPIWeatherModel.temp.value;
            }

            return temp;
        }

        public List<ClimaCellAPIForecast> getForecast(double latitude, double longitude, string now, string time)
        {

            List<ClimaCellAPIForecast> forecastList = new List<ClimaCellAPIForecast>(); // <-- list[0]
            string response = getResponse(climaCellAPIEndpoint.getTemperatureForecast(latitude, longitude, now, time));

            using (JsonParser<List<ClimaCellAPIForecastModel>> jsonParser = new JsonParser<List<ClimaCellAPIForecastModel>>())
            {
                List<ClimaCellAPIForecastModel> climaCellAPIForecastModel = new List<ClimaCellAPIForecastModel>();
                climaCellAPIForecastModel = jsonParser.parse(response, netCoreVersion);
                foreach(ClimaCellAPIForecastModel model in climaCellAPIForecastModel)// <-- obj
                {
                    forecastList.Add(new ClimaCellAPIForecast(model.temp[0].min.value,model.temp[1].max.value)); // the [0] and [1] correspond to the 2 elements in the innder list
                }
            }

            return forecastList;
        }

    }
}
