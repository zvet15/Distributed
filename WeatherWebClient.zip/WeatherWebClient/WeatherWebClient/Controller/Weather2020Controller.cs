﻿using System;
using System.Collections.Generic;
using System.Text;
using WeatherWebClient.Endpoints;
using WeatherWebClient.JSONParser;
using WeatherWebClient.Models;

namespace WeatherWebClient.Controller
{
    class Weather2020Controller:Controller
    {
        private Weather2020APIEndpoint weather2020APIEndpoint;


        public Weather2020Controller() : base()
        {
            weather2020APIEndpoint = new Weather2020APIEndpoint();
        }

        public string getCurrentWeather(double latitude, double longitude)
        {
            /**** Current Weather ****/

            double highTemp = 0f;
            double lowTemp = 0f;

            string response = getResponse(weather2020APIEndpoint.getWeather(latitude, longitude));

            System.Diagnostics.Debug.WriteLine(response);

            using (JsonParser <List<Weather2020Model>> jsonParser = new JsonParser<List<Weather2020Model>>())
            {

                List <Weather2020Model> weather2020Model = new List<Weather2020Model>();
                weather2020Model = jsonParser.parse(response, netCoreVersion);

                highTemp = weather2020Model[0].temperatureHigh; 
                lowTemp = weather2020Model[0].temperatureLow; 
            }
 
            return "High "+highTemp+", Low "+lowTemp;
        }
    }
}
