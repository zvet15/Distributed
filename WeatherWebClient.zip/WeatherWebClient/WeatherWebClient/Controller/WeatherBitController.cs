﻿using System;
using System.Collections.Generic;
using System.Text;
using WeatherWebClient.Endpoints;
using WeatherWebClient.JSONParser;
using WeatherWebClient.Models.Forecast;
using WeatherWebClient.Models.Weather;
using WeatherWebClient.POCO;
using Data = WeatherWebClient.Models.Forecast.Data;

namespace WeatherWebClient.Controller
{
    class WeatherBitController:Controller
    {
        private WeatherBitAPIEndpoint weatherBitAPIEndpoint;
        public WeatherBitController() : base()
        {
            weatherBitAPIEndpoint = new WeatherBitAPIEndpoint();
        }

        public float getCurrentWeather(string city, string country)
        {
            /**** Current Weather ****/

            float temperature = 0f;

            weatherBitAPIEndpoint.endpointType = EndpointType.CURRENT;

            string response = getResponse(weatherBitAPIEndpoint.getByCityNameEndpoint(city, country));

            System.Diagnostics.Debug.WriteLine(response);

            using (JsonParser<WeatherBitAPIWeatherModel> jsonParser = new JsonParser<WeatherBitAPIWeatherModel>())
            {
                WeatherBitAPIWeatherModel weatherBitAPIWeatherModel = new WeatherBitAPIWeatherModel();
                weatherBitAPIWeatherModel = jsonParser.parse(response, netCoreVersion);

                temperature = weatherBitAPIWeatherModel.data[0].temp;
            }

            return temperature;
        }
        public List<WeatherBitAPIForecast> getForecast(string city)
        {
            /**** FORECAST****/

            List<WeatherBitAPIForecast> forecastList = new List<WeatherBitAPIForecast>();

            weatherBitAPIEndpoint.endpointType = EndpointType.FORECAST;
            string response = getResponse(weatherBitAPIEndpoint.getByCityNameForecastEndpoint(city));

            using (JsonParser<WeatherBitAPIForecastModel> jsonParser = new JsonParser<WeatherBitAPIForecastModel>())
            {
                WeatherBitAPIForecastModel weatherBitAPIForecastModel = new WeatherBitAPIForecastModel();
                weatherBitAPIForecastModel = jsonParser.parse(response, netCoreVersion);

                foreach (Data data in weatherBitAPIForecastModel.data)
                {
                    forecastList.Add(new WeatherBitAPIForecast(data.datetime, data.min_temp,data.max_temp));
                }
            }
            
            return forecastList;
        }




    }
}
